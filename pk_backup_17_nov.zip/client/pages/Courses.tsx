import React, { useEffect, useState } from "react";
import { Plus, Trash2, X, Video } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';
import config from '../config';


interface Course {
  course_id: number;
  course_name: string;
  course_link: string;
}

const Courses: React.FC = () => {
  const { user, isAdmin, isSuperAdmin } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [courseName, setCourseName] = useState('');
  const [courseLink, setCourseLink] = useState('');
  const [adding, setAdding] = useState(false);

  // Extract YouTube video ID for thumbnail (supports both regular videos and shorts)
  const getYoutubeThumbnail = (url: string) => {
    // Match regular YouTube videos
    let match = url.match(/(?:youtube\.com\/.*v=|youtu\.be\/)([^&\n?#]+)/);
    if (match) {
      return `https://img.youtube.com/vi/${match[1]}/0.jpg`;
    }
    
    // Match YouTube shorts
    match = url.match(/youtube\.com\/shorts\/([^&\n?#]+)/);
    if (match) {
      return `https://img.youtube.com/vi/${match[1]}/0.jpg`;
    }
    
    return "";
  };
  
  // Get embed URL for YouTube videos/shorts
  const getYoutubeEmbedUrl = (url: string) => {
    // Match regular YouTube videos
    let match = url.match(/(?:youtube\.com\/.*v=|youtu\.be\/)([^&\n?#]+)/);
    if (match) {
      return `https://www.youtube.com/embed/${match[1]}`;
    }
    
    // Match YouTube shorts
    match = url.match(/youtube\.com\/shorts\/([^&\n?#]+)/);
    if (match) {
      return `https://www.youtube.com/embed/${match[1]}`;
    }
    
    return url;
  };

  // Fetch courses
  const fetchCourses = async () => {
    setLoading(true);
    try {
      const headers: Record<string, string> = {};
      if (user?.token) {
        headers['Authorization'] = `Bearer ${user.token}`;
      }
      
      const response = await fetch(config.COURSES_LIST, {
        method: "GET",
        headers
      });
      const result = await response.json();
      if (result.status === 1 && result.data) {
        setCourses(result.data);
      }
    } catch (err) {
      console.error("Failed to fetch courses", err);
    }
    setLoading(false);
  };

  // Add course
  const handleAddCourse = async () => {
    if (!courseName.trim() || !courseLink.trim() || !user?.token) {
      alert('Please fill in all fields');
      return;
    }

    setAdding(true);
    try {
      const response = await fetch(config.COURSES_CREATE, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user.token}`
        },
        body: JSON.stringify({
          course_name: courseName,
          course_link: courseLink
        })
      });

      if (response.ok) {
        await fetchCourses();
        setShowAddModal(false);
        setCourseName('');
        setCourseLink('');
      } else {
        const error = await response.json();
        alert(error.detail || 'Failed to add course');
      }
    } catch (error) {
      console.error('Error adding course:', error);
      alert('Error adding course');
    } finally {
      setAdding(false);
    }
  };

  // Delete course
  const handleDeleteCourse = async (courseId: number) => {
    if (!user?.token) return;
    if (!confirm('Are you sure you want to delete this course?')) return;

    try {
      const response = await fetch(config.COURSES_DELETE(courseId), {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${user.token}`
        }
      });

      if (response.ok) {
        await fetchCourses();
      } else {
        const error = await response.json();
        alert(error.detail || 'Failed to delete course');
      }
    } catch (error) {
      console.error('Error deleting course:', error);
      alert('Error deleting course');
    }
  };

  useEffect(() => {
    fetchCourses();
  }, []);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-pink-700">
          Courses
        </h1>
        {(isAdmin() || isSuperAdmin()) && (
          <Button
            onClick={() => setShowAddModal(true)}
            className="bg-pink-500 hover:bg-pink-600"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Course
          </Button>
        )}
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-500"></div>
        </div>
      ) : courses.length === 0 ? (
        <div className="text-center py-12">
          <Video className="w-16 h-16 mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-semibold text-gray-600 mb-2">No courses available</h3>
          <p className="text-gray-500">Courses will appear here when they are added.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {courses.map((course) => (
            <div
              key={course.course_id}
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow group relative"
            >
              {(isAdmin() || isSuperAdmin()) && (
                <Button
                  variant="destructive"
                  size="sm"
                  className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => handleDeleteCourse(course.course_id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              )}
              
              {course.course_link && (
                <a
                  href={course.course_link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block"
                >
                  <div className="relative aspect-video bg-gray-100">
                    <img
                      src={getYoutubeThumbnail(course.course_link)}
                      alt={course.course_name}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.currentTarget.src = '/placeholder.svg';
                      }}
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/30 transition-colors">
                      <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center">
                        <div className="w-0 h-0 border-t-8 border-t-transparent border-l-12 border-l-white border-b-8 border-b-transparent ml-1"></div>
                      </div>
                    </div>
                  </div>
                </a>
              )}
              
              <div className="p-4">
                <h2 className="text-lg font-semibold text-pink-700 line-clamp-2">
                  {course.course_name}
                </h2>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Course Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999] p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Add Course</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setShowAddModal(false);
                  setCourseName('');
                  setCourseLink('');
                }}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="course_name">Course Name</Label>
                <Input
                  id="course_name"
                  value={courseName}
                  onChange={(e) => setCourseName(e.target.value)}
                  placeholder="Enter course name"
                />
              </div>
              
              <div>
                <Label htmlFor="course_link">YouTube Link</Label>
                <Input
                  id="course_link"
                  value={courseLink}
                  onChange={(e) => setCourseLink(e.target.value)}
                  placeholder="https://youtube.com/..."
                />
                <p className="text-xs text-gray-500 mt-1">
                  Supports regular YouTube videos and Shorts
                </p>
              </div>
              
              <div className="flex space-x-2">
                <Button
                  onClick={handleAddCourse}
                  disabled={adding || !courseName.trim() || !courseLink.trim()}
                  className="flex-1 bg-pink-500 hover:bg-pink-600"
                >
                  {adding ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Adding...
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Course
                    </>
                  )}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowAddModal(false);
                    setCourseName('');
                    setCourseLink('');
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Courses;
