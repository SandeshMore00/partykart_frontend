import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Upload, X, Image as ImageIcon, Plus, Trash2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import config from '../config';
import { Category, SubCategory, Product, ProductImage } from '@shared/api';

interface EditProductFormData {
  product_name: string;
  product_price: string;
  product_full_price: string; // Optional original/full price
  product_description: string;
  sub_category_id: string;
  stock: string;
  files: File[];
  // Optional shipping fields
  weight: string;
  length: string;
  width: string;
  height: string;
  origin_location: string;
}

export default function EditProduct() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [fetchingProduct, setFetchingProduct] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  // Product data
  const [product, setProduct] = useState<Product | null>(null);
  const [originalData, setOriginalData] = useState<EditProductFormData | null>(null);
  
  // Form data
  const [formData, setFormData] = useState<EditProductFormData>({
    product_name: '',
    product_price: '',
    product_full_price: '', // Optional original/full price
    product_description: '',
    sub_category_id: '',
    stock: '',
    files: [],
    // Optional shipping fields
    weight: '',
    length: '',
    width: '',
    height: '',
    origin_location: ''
  });
  
  // Subcategories only
  const [subcategories, setSubcategories] = useState<SubCategory[]>([]);
  const [loadingSubcategories, setLoadingSubcategories] = useState(true);
  
  // Image previews and management
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [existingImageUrls, setExistingImageUrls] = useState<string[]>([]);
  const [deletedImageUrls, setDeletedImageUrls] = useState<string[]>([]);

  useEffect(() => {
    if (id) {
      fetchProduct(parseInt(id));
      fetchSubcategories();
    }
  }, [id]);

  const fetchSubcategories = async () => {
    try {
      const response = await fetch(config.CATEGORY_SUBCATEGORY());
      if (response.ok) {
        const result = await response.json();
        if (result.status === 1) {
          setSubcategories(result.data);
        }
      }
    } catch (error) {
      console.error('Error fetching subcategories:', error);
    } finally {
      setLoadingSubcategories(false);
    }
  };

  const fetchProduct = async (productId: number) => {
    try {
      const response = await fetch(config.PRODUCT_DETAIL_ADMIN(productId));
      if (response.ok) {
        const result = await response.json();
        console.log('Product details response:', result);
        if (result.status === 1) {
          const productData = result.data;
          setProduct(productData);
          
          // Get image URLs from product_images array (array of strings)
          const imageUrls = productData.product_images || [];
          console.log('Product images from API:', imageUrls);
          setExistingImageUrls(imageUrls);
          
          const initialFormData = {
            product_name: productData.product_name,
            product_price: productData.product_price.toString(),
            product_full_price: productData.product_full_price?.toString() || '', // Optional original/full price
            product_description: productData.product_description || '',
            sub_category_id: productData.sub_category_id.toString(),
            stock: productData.stock?.toString() || '',
            files: [],
            // Optional shipping fields
            weight: productData.weight?.toString() || '',
            length: productData.length?.toString() || '',
            width: productData.width?.toString() || '',
            height: productData.height?.toString() || '',
            origin_location: productData.origin_location || ''
          };
          
          setFormData(initialFormData);
          setOriginalData(initialFormData);
        } else {
          setError('Product not found');
        }
      } else {
        setError('Failed to fetch product');
      }
    } catch (error) {
      console.error('Error fetching product:', error);
      setError('An error occurred while fetching the product');
    } finally {
      setFetchingProduct(false);
    }
  };

  const handleInputChange = (field: keyof EditProductFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Only allow integers (no decimals)
    if (/^\d*$/.test(value)) {
      setFormData(prev => ({ ...prev, product_price: value }));
    }
  };

  const handleStockChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Only allow integers (no decimals)
    if (/^\d*$/.test(value)) {
      setFormData(prev => ({ ...prev, stock: value }));
    }
  };

  const handleFullPriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Only allow integers (no decimals)
    if (/^\d*$/.test(value)) {
      setFormData(prev => ({ ...prev, product_full_price: value }));
    }
  };

  const handleNumericChange = (field: 'weight' | 'length' | 'width' | 'height', value: string) => {
    // Allow decimal numbers for shipping dimensions
    if (/^\d*\.?\d*$/.test(value)) {
      setFormData(prev => ({ ...prev, [field]: value }));
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    
    // Validate file types and sizes
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    const maxSize = 512000; // 500 KB in bytes
    
    for (const file of files) {
      // Check file type
      if (!validTypes.includes(file.type)) {
        setError('Please upload only valid image files (JPEG, PNG, GIF, or WebP)');
        e.target.value = '';
        return;
      }
      // Check file size
      if (file.size > maxSize) {
        setError(`Image "${file.name}" is too large. Maximum size is 500 KB. Current size: ${(file.size / 1024).toFixed(2)} KB`);
        e.target.value = '';
        return;
      }
    }
    
    const newFiles = [...formData.files, ...files];
    
    // Limit to 10 files total (existing + new)
    const remainingExistingCount = existingImageUrls.length - deletedImageUrls.length;
    const totalImages = remainingExistingCount + newFiles.length;
    if (totalImages > 10) {
      setError('Maximum 10 images allowed (including existing images)');
      e.target.value = '';
      return;
    }
    
    setError(''); // Clear any previous errors
    setFormData(prev => ({ ...prev, files: newFiles }));
    
    // Create previews
    const newPreviews = files.map(file => URL.createObjectURL(file));
    setImagePreviews(prev => [...prev, ...newPreviews]);
  };

  const removeNewImage = (index: number) => {
    const newFiles = formData.files.filter((_, i) => i !== index);
    const newPreviews = imagePreviews.filter((_, i) => i !== index);
    
    setFormData(prev => ({ ...prev, files: newFiles }));
    setImagePreviews(newPreviews);
  };

  const removeExistingImage = (imageUrl: string) => {
    setDeletedImageUrls(prev => [...prev, imageUrl]);
  };

  const restoreExistingImage = (imageUrl: string) => {
    setDeletedImageUrls(prev => prev.filter(url => url !== imageUrl));
  };

  const validateForm = (): boolean => {
    if (!formData.product_name.trim()) {
      setError('Product name is required');
      return false;
    }
    if (!formData.product_price.trim()) {
      setError('Product price is required');
      return false;
    }
    if (isNaN(parseInt(formData.product_price)) || parseInt(formData.product_price) <= 0) {
      setError('Product price must be a valid positive integer');
      return false;
    }
    // Stock is optional, but if provided, it must be valid
    if (formData.stock.trim() && (isNaN(parseInt(formData.stock)) || parseInt(formData.stock) < 0)) {
      setError('Stock must be a valid non-negative integer');
      return false;
    }
    if (!formData.sub_category_id) {
      setError('Subcategory is required');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    if (!validateForm()) return;
    
    setLoading(true);
    
    try {
      const formDataToSend = new FormData();
      
      // Only append changed fields
      if (originalData) {
        if (formData.product_name !== originalData.product_name) {
          formDataToSend.append('product_name', formData.product_name);
        }
        if (formData.product_price !== originalData.product_price) {
          formDataToSend.append('product_price', parseInt(formData.product_price).toString());
        }
        // Full price is optional - send if changed
        if (formData.product_full_price !== originalData.product_full_price) {
          if (formData.product_full_price.trim()) {
            formDataToSend.append('product_full_price', parseInt(formData.product_full_price).toString());
          }
        }
        if (formData.product_description !== originalData.product_description) {
          formDataToSend.append('product_description', formData.product_description);
        }
        if (formData.stock !== originalData.stock) {
          if (formData.stock.trim()) {
            formDataToSend.append('stock', parseInt(formData.stock).toString());
          }
        }
        if (formData.sub_category_id !== originalData.sub_category_id) {
          formDataToSend.append('sub_category_id', formData.sub_category_id);
        }
        
        // Check optional shipping fields
        if (formData.weight !== originalData.weight && formData.weight.trim()) {
          formDataToSend.append('weight', formData.weight);
        }
        if (formData.length !== originalData.length && formData.length.trim()) {
          formDataToSend.append('length', formData.length);
        }
        if (formData.width !== originalData.width && formData.width.trim()) {
          formDataToSend.append('width', formData.width);
        }
        if (formData.height !== originalData.height && formData.height.trim()) {
          formDataToSend.append('height', formData.height);
        }
        if (formData.origin_location !== originalData.origin_location && formData.origin_location.trim()) {
          formDataToSend.append('origin_location', formData.origin_location);
        }
      }
      
      // Handle images: send remaining images (non-deleted) as existing_images
      const remainingImages = existingImageUrls.filter(url => !deletedImageUrls.includes(url));
      
      // Always send existing_images if there are any image changes (deletions or additions)
      if (deletedImageUrls.length > 0 || formData.files.length > 0) {
        // Send only the images that should be kept (not deleted)
        formDataToSend.append('existing_images', JSON.stringify(remainingImages));
        console.log('Sending existing_images:', remainingImages);
      }
      
      // Append new files to upload
      formData.files.forEach((file, index) => {
        console.log(`Appending new file ${index}:`, {
          name: file.name,
          size: file.size,
          type: file.type
        });
        formDataToSend.append('files', file, file.name);
      });
      
      const response = await fetch(config.PRODUCT_UPDATE(id!), {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${user?.token}`
        },
        body: formDataToSend
      });
      
      if (response.ok) {
        const result = await response.json();
        if (result.status === 1) {
          setSuccess('Product updated successfully!');
          // Scroll to top to show success message
          window.scrollTo({ top: 0, behavior: 'smooth' });
          // Refresh the page after showing message
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        } else {
          setError(result.message || 'Failed to update product');
        }
      } else {
        const errorData = await response.json();
        setError(errorData.message || 'Failed to update product');
      }
    } catch (error) {
      console.error('Error updating product:', error);
      setError('An error occurred while updating the product');
    } finally {
      setLoading(false);
    }
  };

  if (fetchingProduct || loadingSubcategories) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gray-900"></div>
          <p className="mt-4 text-gray-600">Loading product data...</p>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Product Not Found</h1>
          <Button onClick={() => navigate('/admin')}>Back to Admin</Button>
        </div>
      </div>
    );
  }

  const remainingImages = existingImageUrls.filter(url => !deletedImageUrls.includes(url));

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Edit Product</h1>
          <p className="text-gray-600 mt-2">Update product information and images</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Product Information</CardTitle>
            <CardDescription>
              Update the details for your product. You can upload new images or remove existing ones.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              {success && (
                <Alert className="border-green-200 bg-green-50">
                  <AlertDescription className="text-green-800">{success}</AlertDescription>
                </Alert>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="product_name">Product Name *</Label>
                  <Input
                    id="product_name"
                    value={formData.product_name}
                    onChange={(e) => handleInputChange('product_name', e.target.value)}
                    placeholder="Enter product name"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="product_price">Selling Price * (Integer only)</Label>
                  <Input
                    id="product_price"
                    type="text"
                    inputMode="numeric"
                    value={formData.product_price}
                    onChange={handlePriceChange}
                    placeholder="Enter selling price (e.g., 100)"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="product_full_price">Original/Full Price (Optional - Integer only)</Label>
                  <Input
                    id="product_full_price"
                    type="text"
                    inputMode="numeric"
                    value={formData.product_full_price}
                    onChange={handleFullPriceChange}
                    placeholder="Enter original price (e.g., 150)"
                  />
                  <p className="text-xs text-gray-500">Leave empty if no discount. This shows crossed-out price.</p>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="stock">Stock (Optional - Integer only)</Label>
                <Input
                  id="stock"
                  type="text"
                  inputMode="numeric"
                  value={formData.stock}
                  onChange={handleStockChange}
                  placeholder="Enter stock quantity (e.g., 50)"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="product_description">Description</Label>
                <Textarea
                  id="product_description"
                  value={formData.product_description}
                  onChange={(e) => handleInputChange('product_description', e.target.value)}
                  placeholder="Enter product description"
                  rows={4}
                />
              </div>

              {/* Shipping Information Section */}
              <div className="space-y-4">
                <div className="border-t pt-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Shipping Information (Optional)</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="weight">Weight (kg)</Label>
                      <Input
                        id="weight"
                        type="number"
                        step="0.01"
                        min="0"
                        value={formData.weight}
                        onChange={(e) => handleNumericChange('weight', e.target.value)}
                        placeholder="e.g., 1.5"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="origin_location">Origin Location</Label>
                      <Input
                        id="origin_location"
                        value={formData.origin_location}
                        onChange={(e) => handleInputChange('origin_location', e.target.value)}
                        placeholder="e.g., New York, USA"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                    <div className="space-y-2">
                      <Label htmlFor="length">Length (cm)</Label>
                      <Input
                        id="length"
                        type="number"
                        step="0.01"
                        min="0"
                        value={formData.length}
                        onChange={(e) => handleNumericChange('length', e.target.value)}
                        placeholder="e.g., 25.5"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="width">Width (cm)</Label>
                      <Input
                        id="width"
                        type="number"
                        step="0.01"
                        min="0"
                        value={formData.width}
                        onChange={(e) => handleNumericChange('width', e.target.value)}
                        placeholder="e.g., 15.0"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="height">Height (cm)</Label>
                      <Input
                        id="height"
                        type="number"
                        step="0.01"
                        min="0"
                        value={formData.height}
                        onChange={(e) => handleNumericChange('height', e.target.value)}
                        placeholder="e.g., 10.5"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Subcategory *</Label>
                <Select 
                  value={formData.sub_category_id} 
                  onValueChange={(value) => handleInputChange('sub_category_id', value)}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select a subcategory" />
                  </SelectTrigger>
                  <SelectContent 
                    position="popper"
                    className="max-h-[min(300px,50vh)] overflow-y-auto z-[99999]"
                    sideOffset={4}
                  >
                    {subcategories.map((subcategory) => (
                      <SelectItem 
                        key={subcategory.sub_category_id} 
                        value={subcategory.sub_category_id.toString()}
                        className="cursor-pointer hover:bg-gray-100"
                      >
                        {subcategory.sub_category_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-4">
                <Label>Product Images (up to 10)</Label>
                
                {/* Existing Images */}
                {remainingImages.length > 0 && (
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">Current Images</Label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {remainingImages.map((imageUrl, index) => (
                        <div key={imageUrl} className="relative group">
                          <img
                            src={imageUrl.startsWith('http') ? imageUrl : `${config.PRODUCTS_SERVICE_URL}${imageUrl}`}
                            alt={`Product image ${index + 1}`}
                            className="w-full h-32 object-cover rounded-lg border"
                          />
                          <button
                            type="button"
                            onClick={() => removeExistingImage(imageUrl)}
                            className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                          {index === 0 && (
                            <div className="absolute bottom-2 left-2 bg-blue-500 text-white text-xs px-2 py-1 rounded">
                              Main
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Images marked for deletion */}
                {deletedImageUrls.length > 0 && (
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-red-700">Images to be deleted</Label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {deletedImageUrls.map((imageUrl, index) => (
                        <div key={imageUrl} className="relative group opacity-50">
                          <img
                            src={imageUrl.startsWith('http') ? imageUrl : `${config.PRODUCTS_SERVICE_URL}${imageUrl}`}
                            alt={`Deleted image ${index + 1}`}
                            className="w-full h-32 object-cover rounded-lg border border-red-300"
                          />
                          <button
                            type="button"
                            onClick={() => restoreExistingImage(imageUrl)}
                            className="absolute top-2 right-2 bg-green-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <Plus className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Upload new images */}
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
                  <div className="text-center">
                    <Upload className="mx-auto h-12 w-12 text-gray-400" />
                    <div className="mt-4">
                      <Label htmlFor="file-upload" className="cursor-pointer">
                        <span className="mt-2 block text-sm font-medium text-gray-900">
                          Upload new images
                        </span>
                        <span className="mt-1 block text-sm text-gray-500">
                          JPEG, PNG, GIF, WebP - Max 500 KB each
                        </span>
                      </Label>
                      <Input
                        id="file-upload"
                        type="file"
                        multiple
                        accept="image/jpeg,image/jpg,image/png,image/gif,image/webp"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                    </div>
                  </div>
                </div>

                {/* New image previews */}
                {imagePreviews.length > 0 && (
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-green-700">New Images</Label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {imagePreviews.map((preview, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={preview}
                            alt={`Preview ${index + 1}`}
                            className="w-full h-32 object-cover rounded-lg border border-green-300"
                          />
                          <div className="absolute bottom-0 left-0 right-0 bg-black/70 text-white text-xs px-2 py-1 rounded-b-lg">
                            {(formData.files[index].size / 1024).toFixed(2)} KB
                          </div>
                          <button
                            type="button"
                            onClick={() => removeNewImage(index)}
                            className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="flex gap-4 pt-6">
                <Button
                  type="submit"
                  disabled={loading}
                  className="flex-1"
                >
                  {loading ? 'Updating...' : 'Update Product'}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate('/admin')}
                  className="flex-1"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
